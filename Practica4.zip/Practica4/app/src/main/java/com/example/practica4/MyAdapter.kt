package com.example.practica4

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class MyAdapter(
    private val context: Context,
    private val layout: Int,
    private val nombres: MutableList<String>
):
    BaseAdapter() {
    override fun getCount(): Int{
        return nombres.size
    }
    override fun getItem(position: Int): Any {
        return nombres[position]
    }

    override fun getItemId(id: Int): Long {
        return id.toLong()
    }

    override fun getView(position: Int, convertView: View, parent: ViewGroup): View {
        var vista= convertView
        val layoutInflater= LayoutInflater.from(context)
        vista = layoutInflater.inflate(R.layout.list_item, null )

        val nombre= nombres[position]
        val tv: TextView = vista.findViewById(R.id.AlmeriaText)
        tv.text= nombre
        return vista
    }

}