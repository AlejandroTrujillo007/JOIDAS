package com.example.practica4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast

class MainActivity : AppCompatActivity(), AdapterView.OnItemClickListener{
    val items= mutableListOf("Almeria","Cadiz","Cordoba",
        "Granada","Huelva","Jaen",
        "Malaga","Sevilla")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val lv: ListView =findViewById(R.id.lvLista)
        val adapter= MyAdapter(this,R.layout.list_item, items )
        lv.adapter=adapter
        lv.setOnItemClickListener(this)
    }

    override fun onItemClick(position: AdapterView<*>?, p1: View?, p2: Int, p3 :Long) {
        val toast: Toast = Toast.makeText( this, "Has pulsado sobre "+items[p2],Toast.LENGTH_SHORT )
        toast.show()
    }
}